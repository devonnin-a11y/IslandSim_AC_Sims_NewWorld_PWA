window.state = {
  sim: {
    x: 400,
    y: 220,
    speed: 4,
    mood: "Happy",
    queue: []
  }
};
